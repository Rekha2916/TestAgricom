package com.farm.dao;
import org.springframework.jdbc.core.JdbcTemplate;
import com.farm.model.FarmerCrop;


public class FarmerDAO {
	JdbcTemplate jdbcTemplate;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public int saveData(FarmerCrop e)
	{
		System.out.println("in save data..");
		String query="insert into Farm_Crops values(' "+e.getcId()+"','"+e.getcType()+"','"+e.getcName()+"','"+e.getcFertilizerType()+"','"+e.getcQuantity()+"','"+e.getcStatus()+"','"+e.getcBasePrice()+"','"+e.getcSellPrice()+" ' )";
		return jdbcTemplate.update(query);
	}
}
